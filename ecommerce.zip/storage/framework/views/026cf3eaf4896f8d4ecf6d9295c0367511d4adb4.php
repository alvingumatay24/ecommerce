<?php $__env->startSection('title', $products->name); ?>

<?php $__env->startSection('content'); ?>
<div class="py-3 mb-4 shadow-sm bg-warning border-top">
    <div class="container">
          <h6 class="mb-0">
            <a href="<?php echo e(url('category')); ?>" style="color:#fff">
               Collections /
            </a>
            <a href="<?php echo e(url('category/'.$products->category->slug)); ?>" style="color:#fff">
                <?php echo e($products->category->name); ?> /
            </a>
            <a href="<?php echo e(url('category/'.$products->category->slug.'/'.$products->slug)); ?>" style="color:#fff">
            <?php echo e($products->name); ?>

            </a>
          </h6>
    </div>
</div>

  <div class="container">
    <div class="card shadow product_data">
        <div class="card-body">
            <?php echo csrf_field(); ?>
           <div class="row">
            <div class="col-md-4 border-right">
                  <img src="<?php echo e(asset('assets/uploads/products/'.$products->image)); ?>" class="w-100" alt="">
            </div>
            <div class="col-md-8">
                <h2 class="mb-0">
                    <?php echo e($products->name); ?>

                    <?php if($products->trending == '1'): ?>
                    <label style="font-size: 16px;" class="float-end badge bg-danger trending_tag">Trending</label>
                    <?php endif; ?>
                </h2>
                <hr/>
                <label  class="me-3"> Original Price : <s>Rs <?php echo e($products->original_price); ?></s></label>
                <label  class="fw-bold">Selling Price : Rs <?php echo e($products->selling_price); ?> </label>
                <p class="mt-3">
                    <?php echo $products->small_description; ?>

                </p>
                <hr/>
                <?php if($products->qty > 0 ): ?>
                   <label  class="badge bg-success">In Stock</label>
                <?php else: ?>
                  <label  class="badge bg-danger">Out of Stock</label>
                <?php endif; ?>
               <div class="row mt-2">
                  <div class="col-md-3">
                       <input type="hidden" value="<?php echo e($products->id); ?>" class="prod_id">
                       <label for="Quantity">Quantity</label>
                       <div class="input-group text-center mb-3" style="width:130px;">
                           <button class="input-group-text decrement-btn">-</button>
                           <input type="text" name="quantity"  class="form-control qty-input text-center" value="<?php echo e($products->qty); ?>"/>
                           <button class="input-group-text increment-btn">+</button>
                       </div>
                  </div>
                  <div class="col-md-9">
                    <br/>
                    <?php if($products->qty > 0 ): ?>
                      <button type="button " class="btn btn-primary me-3 addToCartBtn  float-start"><i class="fa fa-shopping-cart"></i> Add To Cart</button>
                   <?php endif; ?>
                     <button type="button" class="btn btn-success me-3  addToWishlist float-start"> <i class="fa fa-heart"></i> Add To Wishlist</button>
                  </div>
               </div>
            </div>
            <div class="col-md-12">
                <hr/>
                <h3>Description</h3>
                <p class="mt-3">
                    <?php echo $products->description; ?>

                </p>
            </div>
           </div>
        </div>
    </div>
  </div>
  <?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce\resources\views/frontend/products/view.blade.php ENDPATH**/ ?>