@extends('layouts.admin')

@section('content')
      <div class="card">
          <div class="card-body">
             <h1>Dark Coder</h1>
          </div>
      </div>
@endsection
